from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np, json, math
from PIL import ImageColor
root=Path(__file__).parent/'原片'
def linear(rgb):
    c=rgb/255.
    return np.where(c<=.04045,c/12.92,((c+.055)/1.055)**2.4)
def luma(rgb): return linear(rgb)@np.array([.2126,.7152,.0722])
def measure(name,kind,size):
    meta=json.loads((root/f'{name}-{kind}-{size}.json').read_text('utf-8-sig'))
    raw=np.array(Image.open(root/f'{name}-{kind}-{size}.png').convert('RGB'))
    lum=luma(raw)
    vals={}
    for feature in ['tip','line','glyph']:
        x,y=meta['features'][feature]; fac=raw.shape[1]/meta['width']
        r=({'tip':5,'line':4,'glyph':9} if size=='desktop' else {'tip':4,'line':3,'glyph':7})[feature]
        xx=round(x*fac); yy=round(y*fac); rr=round(r*fac)
        roi=lum[yy-rr:yy+rr+1,xx-rr:xx+rr+1]
        low,high=np.percentile(roi,[5,90])
        vals[feature]=round((high+.05)/(low+.05),3)
    # Compare identical pixels under identical exposure with and without cast shadows.
    clear=luma(np.array(Image.open(root/f'clear-{name}-{kind}-{size}.png').convert('RGB')))
    x,y=meta['features']['tip']; scale=raw.shape[1]/meta['width']; x,y=round(x*scale),round(y*scale)
    r=round((5 if size=='desktop' else 4)*scale)
    slab=np.s_[y-r:y+r+1,x-r:x+r+1]
    ratio=(clear[slab]+.05)/(lum[slab]+.05)
    vals['isolatedShadow']=round(float(np.percentile(ratio,95)),3)
    return vals
def hue(rgb):
    rgb=rgb.astype(float)
    r,g,b=rgb.T; top=np.max(rgb,axis=1);d=top-np.min(rgb,axis=1);ok=d>0
    f=np.where(ok,d,1.)
    h=np.select([top==r,top==g],[(g-b)/f,2+(b-r)/f],default=4.+(r-g)/f)
    return np.where(ok,60*(h%6),-1)
def masks():
    result={}
    palette=json.loads((root/'after-plate-desktop.json').read_text('utf-8-sig'))['palette']
    metal=np.array(ImageColor.getrgb(palette['patina']),dtype='float'); plain=np.array(ImageColor.getrgb(palette['ink']),dtype='float')
    for f in sorted(root.glob('mask-*.png')):
        a=np.array(Image.open(f).convert('RGBA'))
        sel=a[:,:,3]>=254
        tag=f.stem.replace('mask-','')
        actual=f'after-{tag}.png' if tag.endswith(('desktop','mobile')) else f'shape-{tag}.png'
        h=hue(np.array(Image.open(root/actual).convert('RGB'))[sel])
        mat=a[:,:,:3][sel].astype(float)
        # Fractional antialias coverage of a fine seam, averaged over the complete opaque silhouette.
        weights=np.clip((mat-plain)@(metal-plain)/np.sum((metal-plain)**2),0,1)
        result[tag]={'instrumentPixels':int(np.sum(sel)),'patinaPercent':round(100*weights.mean(),4),'greenHuePercent':round(100*np.mean((80<=h)&(h<=170)),4)}
    return result
def components():
    palette=json.loads((root/'after-plate-desktop.json').read_text('utf-8-sig'))['palette']
    result={}
    for key in ['marble','stone','bronze','bronzeDark','gold','lacquer','cinnabar']:
        data=[]; base=np.array(ImageColor.getrgb(palette[key]))
        for tag in ['bowl-desktop','plate-desktop','bowl-mobile','plate-mobile']:
            mat=np.array(Image.open(root/f'parts-{tag}.png').convert('RGBA'))
            mask=np.all(mat[:,:,:3]==base,axis=2)&(mat[:,:,3]==255)
            if mask.any():
                rgb=np.array(Image.open(root/f'after-{tag}.png').convert('RGB'))[mask]; data.append(hue(rgb))
        if data:
            h=np.concatenate(data);h=h[h>=0];hist=np.histogram(h,bins=np.arange(361))[0]
            result[key]={'pixels':len(h),'peak':int(np.argmax(hist)),'greenPercent':round(float(100*np.mean((h>=80)&(h<=170))),4)}
    return result
if __name__=='__main__':
    contrasts={f'{k}-{z}':{v:measure(v,k,z) for v in ['before','after']} for k in ['plate','bowl'] for z in ['desktop','mobile']}
    report={'contrasts':contrasts,'area':masks(),'components':components()}
    (root/'metrics.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
